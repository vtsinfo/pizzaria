from flask import Flask, render_template, request, flash, redirect, url_for, jsonify, session
import os
import json
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'vts_pizzaria_secret_key'

@app.route('/')
def index():
    return render_template('index.html', title='Pizzaria Colonial — Pizzas, Churrasco e Lanches')

@app.route('/cardapio')
def cardapio():
    return render_template('cardapio.html', title='Nosso Cardápio — Pizzaria Colonial')

@app.route('/reservas', methods=['GET', 'POST'])
def reservas():
    if request.method == 'POST':
        # Lógica simplificada de reserva
        flash('Sua solicitação de reserva foi enviada com sucesso! Entraremos em contato para confirmar.', 'success')
        return redirect(url_for('reservas'))
    return render_template('reservas.html', title='Reservas — Pizzaria Colonial')

# Caminho do arquivo JSON
DATA_FILE = os.path.join(os.path.dirname(__file__), 'cardapio.json')
ORDERS_FILE = os.path.join(os.path.dirname(__file__), 'pedidos.json')
HISTORY_FILE = os.path.join(os.path.dirname(__file__), 'pedidos_historico.json')

@app.route('/api/cardapio')
def api_cardapio():
    if not os.path.exists(DATA_FILE):
        # Cria um cardápio padrão se o arquivo não existir
        default_menu = {"Pizzas Salgadas": [{"nome": "Mussarela", "desc": "Molho, mussarela e orégano", "preco": "R$ 48,99"}]}
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(default_menu, f, indent=4, ensure_ascii=False)
            
    try:
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            return jsonify(json.load(f))
    except Exception as e:
        print(f"Erro ao ler cardápio: {e}")
        return jsonify({})

# Rota de Login
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        # Credenciais simples (admin / pizza123)
        username = request.form.get('username')
        password = request.form.get('password')
        if username == 'admin' and password == 'pizza123':
            session['logged_in'] = True
            return redirect(url_for('admin_panel'))
        else:
            error = 'Usuário ou senha incorretos.'
    return render_template('login.html', title='Login — Pizzaria Colonial', error=error)

# Rota de Logout
@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('login'))

# Rota para a interface administrativa
@app.route('/admin')
def admin_panel():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return render_template('admin_cardapio.html', title='Admin — Pizzaria Colonial')

@app.route('/admin/pedidos')
def admin_pedidos():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return render_template('admin_pedidos.html', title='Pedidos em Tempo Real — Pizzaria Colonial')

# Rota para salvar alterações (POST)
@app.route('/api/admin/save', methods=['POST'])
def save_cardapio():
    if not session.get('logged_in'):
        return jsonify({"success": False, "message": "Acesso não autorizado"}), 401
    try:
        data = request.get_json()
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
        return jsonify({"success": True, "message": "Cardápio atualizado com sucesso!"})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

# --- API DE PEDIDOS ---

@app.route('/api/pedido/novo', methods=['POST'])
def novo_pedido():
    try:
        data = request.get_json()
        data['id'] = int(datetime.now().timestamp() * 1000) # ID único baseado no tempo
        data['timestamp'] = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        
        orders = []
        if os.path.exists(ORDERS_FILE):
            with open(ORDERS_FILE, 'r', encoding='utf-8') as f:
                try: 
                    orders = json.load(f)
                except: orders = []
        
        orders.insert(0, data) # Adiciona no topo da lista
        
        with open(ORDERS_FILE, 'w', encoding='utf-8') as f:
            json.dump(orders, f, indent=4, ensure_ascii=False)
            
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/admin/pedidos')
def get_pedidos():
    if not session.get('logged_in'):
        return jsonify([]), 401
    
    if os.path.exists(ORDERS_FILE):
        try:
            with open(ORDERS_FILE, 'r', encoding='utf-8') as f:
                return jsonify(json.load(f))
        except:
            return jsonify([])
            
    return jsonify([])

@app.route('/api/admin/pedido/concluir', methods=['POST'])
def concluir_pedido():
    if not session.get('logged_in'):
        return jsonify({"success": False}), 401
    
    data = request.get_json()
    order_id = data.get('id')
    
    if os.path.exists(ORDERS_FILE):
        try:
            with open(ORDERS_FILE, 'r', encoding='utf-8') as f:
                orders = json.load(f)
        except:
            orders = []
        
        # Arquivar no histórico antes de remover
        order_to_archive = next((o for o in orders if o.get('id') == order_id), None)
        if order_to_archive:
            history = []
            if os.path.exists(HISTORY_FILE):
                try:
                    with open(HISTORY_FILE, 'r', encoding='utf-8') as hf:
                        history = json.load(hf)
                except: history = []
            
            history.insert(0, order_to_archive)
            try:
                with open(HISTORY_FILE, 'w', encoding='utf-8') as hf:
                    json.dump(history, hf, indent=4, ensure_ascii=False)
            except: pass
        
        orders = [o for o in orders if o.get('id') != order_id]
        
        try:
            with open(ORDERS_FILE, 'w', encoding='utf-8') as f:
                json.dump(orders, f, indent=4, ensure_ascii=False)
        except: pass
        
    return jsonify({"success": True})

@app.route('/api/admin/pedido/status', methods=['POST'])
def update_pedido_status():
    if not session.get('logged_in'):
        return jsonify({"success": False}), 401
    
    data = request.get_json()
    order_id = data.get('id')
    new_status = data.get('status')
    
    if os.path.exists(ORDERS_FILE):
        try:
            with open(ORDERS_FILE, 'r', encoding='utf-8') as f:
                orders = json.load(f)
        except:
            orders = []
        
        for order in orders:
            if order.get('id') == order_id:
                order['status'] = new_status
                break
        
        try:
            with open(ORDERS_FILE, 'w', encoding='utf-8') as f:
                json.dump(orders, f, indent=4, ensure_ascii=False)
        except: pass
            
    return jsonify({"success": True})

@app.route('/api/admin/historico')
def get_historico():
    if not session.get('logged_in'):
        return jsonify([]), 401
    
    if os.path.exists(HISTORY_FILE):
        try:
            with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
                return jsonify(json.load(f))
        except:
            return jsonify([])
    return jsonify([])

if __name__ == '__main__':
    app.run(debug=True)
