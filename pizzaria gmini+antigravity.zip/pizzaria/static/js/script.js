document.addEventListener('DOMContentLoaded', function () {
    initAIWidget();
});

function initAIWidget() {
    const widget = document.getElementById('ai-widget-container');
    if (!widget) return;

    const toggleBtn = document.getElementById('ai-toggle-btn');
    const closeBtn = document.getElementById('close-ai-btn');
    const clearBtn = document.getElementById('clear-ai-btn');
    const badge = document.querySelector('.ai-notification-badge');
    const input = document.getElementById('ai-input');
    const sendBtn = document.getElementById('ai-send-btn');
    const messagesContainer = document.getElementById('ai-messages');

    let knowledgeBase = {};
    let fallbackResponse = "Desculpe, não entendi.";
    let awaitingNeighborhood = false;
    let awaitingMenuCategory = false;
    let checkoutState = null; // null, 'method', 'cep', 'address_number', 'switch_method', 'check_saved', 'name', 'phone', 'coupon', 'obs'
    let orderData = {};
    let cart = [];
    let currentUnit = null;

    // Unidades da Pizzaria (Coordenadas Aproximadas)
    const units = [
        { name: "Colonial 1 (Itaquera)", lat: -23.5466, lon: -46.4473, address: "Rua Virgínia Ferni, 1758", phone: "5511914569028" },
        { name: "Colonial 2 (Centenário)", lat: -23.5786, lon: -46.5058, address: "Av. Luís Pires de Minas, 1387", phone: "5511974136101" },
        { name: "Colonial 3 (Paineiras)", lat: -23.5334, lon: -46.4817, address: "Av. Águia de Haia, 1210", phone: "5511974136101" },
        { name: "Colonial 4 (Guarulhos)", lat: -23.4567, lon: -46.5512, address: "Av. Torres Tibagy, 916", phone: "5511937406544" }
    ];

    // Função para calcular distância (Haversine Formula)
    function calculateDistance(lat1, lon1, lat2, lon2) {
        const R = 6371; // Raio da Terra em km
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLon = (lon2 - lon1) * Math.PI / 180;
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }

    // Função para calcular taxa de entrega estimada
    function calculateDeliveryFee(distance) {
        // Taxa base R$ 3,00 + R$ 1,50 por km
        const fee = 3.00 + (distance * 1.50);
        return fee.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    }

    // Função para verificar status da loja
    function getStoreStatus() {
        const now = new Date();
        const day = now.getDay(); // 0=Dom, 1=Seg, ...
        const hour = now.getHours();
        const minutes = now.getMinutes();
        const currentTime = hour + (minutes / 60);

        // Horários: 18:00 às 23:30 (Dom-Qui) / 18:00 às 00:00 (Sex-Sáb)
        const openTime = 18.0;
        let closeTime = 23.5; // 23:30
        let closeTimeStr = "23:30";

        if (day === 5 || day === 6) {
            closeTime = 24.0;
            closeTimeStr = "00:00";
        }

        const isOpen = currentTime >= openTime && currentTime < closeTime;
        let message = "";

        if (isOpen) {
            message = `Estamos abertos até às ${closeTimeStr}!`;
        } else {
            if (currentTime < openTime) {
                message = `Estamos fechados agora. Abrimos às 18:00.`;
            } else {
                message = `Estamos fechados. Voltamos amanhã às 18:00.`;
            }
        }

        return { isOpen, message };
    }

    // Processar verificação de CEP
    async function processDeliveryCheck(cep) {
        awaitingNeighborhood = false;
        try {
            // Busca coordenadas do CEP (Nominatim OpenStreetMap - Gratuito)
            const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&countrycodes=br&limit=1&postalcode=${cep}&addressdetails=1`);
            const data = await response.json();

            if (!data || data.length === 0) {
                awaitingNeighborhood = true;
                return "Não consegui localizar esse CEP. 😓 Poderia me dizer qual é o seu **bairro**?";
            }

            const userLat = parseFloat(data[0].lat);
            const userLon = parseFloat(data[0].lon);

            let nearestUnit = null;
            let minDistance = Infinity;

            units.forEach(unit => {
                const dist = calculateDistance(userLat, userLon, unit.lat, unit.lon);
                if (dist < minDistance) {
                    minDistance = dist;
                    nearestUnit = unit;
                }
            });

            const distFormatted = minDistance.toFixed(1);
            const deliveryFee = calculateDeliveryFee(minDistance);
            const storeStatus = getStoreStatus();

            const address = data[0].address || {};
            const street = address.road || address.street || address.pedestrian || address.footway || "Rua identificada pelo CEP";

            if (minDistance <= 6) {
                currentUnit = nearestUnit;

                let msg = `Boas notícias! 🎉 Localizei a rua <strong>${street}</strong>.<br>Você está a <strong>${distFormatted}km</strong> da unidade <strong>${nearestUnit.name}</strong>.<br>Fazemos entrega aí sim!`;
                msg += `<br>💰 <strong>Taxa de entrega estimada:</strong> ${deliveryFee}`;

                if (!storeStatus.isOpen) {
                    msg += `<br><br>⚠️ <strong>${storeStatus.message}</strong> 🕒<br>Mas você pode deixar agendado!`;
                }

                msg += ` <a href="https://wa.me/${nearestUnit.phone}?text=Olá, gostaria de fazer um pedido para o CEP ${cep}" target="_blank" class="text-white text-decoration-underline">Clique aqui para pedir no WhatsApp</a>.`;
                return msg;
            } else {
                return `Poxa! 😕 A rua <strong>${street}</strong> fica a <strong>${distFormatted}km</strong> da unidade mais próxima (${nearestUnit.name}). Para garantir a qualidade, nosso delivery vai até 6km.<br><br>Mas não fique na vontade! 🍕<br>Venha nos visitar em <strong>${nearestUnit.address}</strong>. O rodízio está incrível e o ambiente é perfeito para sua família. Vale a pena o passeio!`;
            }

        } catch (error) {
            console.error("Erro ao buscar CEP", error);
            return "Tive um problema técnico ao verificar seu CEP. Pode tentar novamente ou chamar no WhatsApp?";
        }
    }

    // Processar verificação de Bairro
    async function processNeighborhoodCheck(neighborhood) {
        try {
            // Busca coordenadas do Bairro (Adiciona "SP" para contexto)
            const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&countrycodes=br&limit=1&q=${encodeURIComponent(neighborhood + ", SP")}`);
            const data = await response.json();

            if (!data || data.length === 0) {
                return "Também não consegui localizar o bairro. 😕<br><br>Mas não fique na vontade! 🍕<br>Venha nos visitar em uma de nossas unidades. O rodízio está incrível e vale a pena o passeio!<br><br><a href='https://www.google.com/maps/search/Pizzaria+Colonial+São+Paulo' target='_blank' class='text-white text-decoration-underline'>Encontrar a unidade mais próxima no Mapa</a>";
            }

            const userLat = parseFloat(data[0].lat);
            const userLon = parseFloat(data[0].lon);

            let nearestUnit = null;
            let minDistance = Infinity;

            units.forEach(unit => {
                const dist = calculateDistance(userLat, userLon, unit.lat, unit.lon);
                if (dist < minDistance) {
                    minDistance = dist;
                    nearestUnit = unit;
                }
            });

            const distFormatted = minDistance.toFixed(1);
            const deliveryFee = calculateDeliveryFee(minDistance);
            const storeStatus = getStoreStatus();

            if (minDistance <= 6) {
                currentUnit = nearestUnit;
                let msg = `Encontrei seu bairro! 🎉 Você está a aprox. <strong>${distFormatted}km</strong> da unidade <strong>${nearestUnit.name}</strong>.<br>Fazemos entrega aí sim!`;
                msg += `<br>💰 <strong>Taxa de entrega estimada:</strong> ${deliveryFee}`;

                if (!storeStatus.isOpen) {
                    msg += `<br><br>⚠️ <strong>${storeStatus.message}</strong> 🕒<br>Mas você pode deixar agendado!`;
                }

                msg += ` <a href="https://wa.me/${nearestUnit.phone}?text=Olá, gostaria de fazer um pedido para o bairro ${neighborhood}" target="_blank" class="text-white text-decoration-underline">Clique aqui para pedir no WhatsApp</a>.`;
                return msg;
            } else {
                return `Poxa! 😕 O bairro ${neighborhood} fica a aprox. <strong>${distFormatted}km</strong> da unidade mais próxima (${nearestUnit.name}). Para garantir a qualidade, nosso delivery vai até 6km.<br><br>Mas não fique na vontade! 🍕<br>Venha nos visitar em <strong>${nearestUnit.address}</strong>.`;
            }
        } catch (error) {
            console.error("Erro ao buscar Bairro", error);
            return "Tive um problema técnico ao verificar seu bairro. Pode tentar chamar no WhatsApp?";
        }
    }

    // --- Favoritos ---
    function getFavorites() {
        return JSON.parse(localStorage.getItem('vts_pizza_favorites')) || [];
    }

    function isFavorite(name) {
        return getFavorites().some(f => f.name === name);
    }

    function toggleFavorite(name, price, desc) {
        let favs = getFavorites();
        const index = favs.findIndex(f => f.name === name);
        if (index > -1) {
            favs.splice(index, 1);
        } else {
            favs.push({ name, price, desc });
        }
        localStorage.setItem('vts_pizza_favorites', JSON.stringify(favs));
    }

    function showFavorites() {
        const favs = getFavorites();
        if (favs.length === 0) {
            addMessage("Você ainda não tem favoritos! ⭐<br>Clique na estrela ao lado dos itens do cardápio para salvar.", 'bot');
            return;
        }

        let html = "<strong>⭐ Seus Favoritos:</strong><br>";
        favs.forEach(item => {
            html += `<div style="margin-bottom: 8px; padding: 4px 0; display: flex; align-items: center; justify-content: space-between;">
                        <div style="flex: 1;">
                            <div style="display: flex; justify-content: space-between;"><strong>${item.name}</strong> <span style="margin-left: 5px;">${item.price}</span></div>
                            <div style="font-size: 0.85em; opacity: 0.8; line-height: 1.2;">${item.desc || ''}</div>
                        </div>
                        <div style="display: flex; gap: 8px; align-items: center; margin-left: 5px;">
                            <button class="fav-btn" data-name="${item.name}" data-price="${item.price}" data-desc="${item.desc || ''}" style="background: transparent; border: none; cursor: pointer; font-size: 1.4em; color: #ffc107; padding: 0;">⭐</button>
                            <button class="add-cart-btn" data-name="${item.name}" data-price="${item.price}" style="background: #28a745; border: none; color: white; width: 28px; height: 28px; border-radius: 50%; cursor: pointer; font-weight: bold; flex-shrink: 0;">+</button>
                        </div>
                     </div>`;
        });

        html += `<div style="margin-top: 15px; text-align: center;">
                    <button class="back-to-menu-btn" style="background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.3); color: white; padding: 8px 16px; border-radius: 20px; cursor: pointer; font-size: 0.9em; transition: background 0.2s;">⬅ Voltar ao Menu</button>
                 </div>`;
        addMessage(html, 'bot');
    }

    // --- Avaliação ---
    function showRatingUI() {
        let html = `<div class="rating-container" style="text-align: center; margin-top: 15px; padding-top: 10px; border-top: 1px dashed rgba(255,255,255,0.2);">
                        <p style="margin-bottom: 5px;">Como foi sua experiência?</p>
                        <div style="font-size: 1.8em; cursor: pointer; letter-spacing: 5px;">
                            <span class="rate-star" data-val="1">☆</span><span class="rate-star" data-val="2">☆</span><span class="rate-star" data-val="3">☆</span><span class="rate-star" data-val="4">☆</span><span class="rate-star" data-val="5">☆</span>
                        </div>
                    </div>`;
        addMessage(html, 'bot');
    }

    // Remover do Carrinho
    function removeFromCart(index) {
        if (index >= 0 && index < cart.length) {
            cart.splice(index, 1);
            showCart();
        }
    }

    // Exibir Carrinho (Editável)
    function showCart() {
        if (cart.length === 0) {
            addMessage("Seu carrinho ficou vazio! 🛒 Que tal adicionar algo?", 'bot');
            showMenuCategories();
            return;
        }

        let total = 0;
        let html = `🛒 <strong>Seu Carrinho:</strong><br>`;

        cart.forEach((item, index) => {
            html += `<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 2px;">
                        <span>${item.name} <small>(${item.price})</small></span>
                        <button class="remove-cart-item-btn" data-index="${index}" style="background: #dc3545; border: none; color: white; width: 24px; height: 24px; border-radius: 50%; cursor: pointer; font-weight: bold; margin-left: 10px; display: flex; align-items: center; justify-content: center;" title="Remover">×</button>
                     </div>`;
            const priceVal = parseFloat(item.price.replace(/[^\d,]/g, '').replace(',', '.'));
            if (!isNaN(priceVal)) total += priceVal;
        });

        const totalFormatted = total.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
        html += `<div style="margin-top: 10px; font-weight: bold;">Total: ${totalFormatted}</div>`;

        html += `<div style="margin-top: 15px; display: flex; gap: 10px; justify-content: center;">
                    <button class="back-to-menu-btn" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 8px 12px; border-radius: 15px; cursor: pointer; font-size: 0.9em;">+ Itens</button>
                    <button class="finalize-order-btn" style="background: #28a745; border: none; color: white; padding: 8px 12px; border-radius: 15px; cursor: pointer; font-size: 0.9em;">✅ Concluir</button>
                 </div>`;

        addMessage(html, 'bot');
    }

    // Adicionar ao Carrinho
    function addToCart(name, price) {
        cart.push({ name, price });
        addMessage(`✅ <strong>${name}</strong> adicionado!<br>🛒 Carrinho: ${cart.length} item(ns).<br><button class="view-cart-btn" style="margin-top: 8px; background: #17a2b8; border: none; color: white; padding: 6px 12px; border-radius: 15px; cursor: pointer; font-size: 0.9em;">Ver Carrinho / Finalizar</button>`, 'bot');
    }

    // Finalizar Pedido
    function finalizeOrder() {
        if (cart.length === 0) {
            addMessage("Seu carrinho está vazio! 🛒 Adicione itens do cardápio primeiro.", 'bot');
            return;
        }

        checkoutState = 'method';
        orderData = { method: '', name: '', phone: '', cep: '', fee: 'R$ 0,00', obs: '', discount: null };

        addMessage("Vamos fechar seu pedido! 📝<br>Como você prefere receber?<br>1️⃣ <strong>Entrega</strong> 🛵<br>2️⃣ <strong>Retirada</strong> 🏪", 'bot');
    }

    // Concluir Checkout e Gerar Link
    function finishCheckout() {
        // Salvar dados no localStorage
        localStorage.setItem('vts_user_name', orderData.name);
        localStorage.setItem('vts_user_phone', orderData.phone);

        let total = 0;
        let msg = `Olá! Gostaria de fazer um pedido (${orderData.method}):\n\n`;
        msg += `👤 *Cliente:* ${orderData.name}\n`;
        msg += `📱 *Tel:* ${orderData.phone}\n`;

        if (orderData.method === 'Entrega') {
            const fullAddress = orderData.street ? `${orderData.street}, ${orderData.number_complement} (${orderData.cep})` : orderData.cep;
            msg += `📍 *Endereço:* ${fullAddress}\n`;
        }

        msg += `\n🛒 *Itens:* \n`;

        cart.forEach(item => {
            msg += `- ${item.name} (${item.price})\n`;
            const priceVal = parseFloat(item.price.replace(/[^\d,]/g, '').replace(',', '.'));
            if (!isNaN(priceVal)) total += priceVal;
        });

        // Adiciona taxa de entrega se houver
        const feeVal = parseFloat(orderData.fee.replace(/[^\d,]/g, '').replace(',', '.'));
        if (!isNaN(feeVal) && feeVal > 0) total += feeVal;

        // Aplica Desconto
        if (orderData.discount) {
            let discountVal = 0;
            if (orderData.discount.tipo === 'fixo') discountVal = parseFloat(orderData.discount.valor);
            else discountVal = total * (parseFloat(orderData.discount.valor) / 100);

            total -= discountVal;
            if (total < 0) total = 0;

            msg += `\n🎟️ *Cupom (${orderData.discount.codigo}):* -${discountVal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}`;
        }

        const totalFormatted = total.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

        // Enviar para o Painel Admin (API)
        fetch('/api/pedido/novo', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                customer: orderData.name,
                phone: orderData.phone,
                method: orderData.method,
                address: orderData.method === 'Entrega' ? (orderData.street ? `${orderData.street}, ${orderData.number_complement} (${orderData.cep})` : orderData.cep) : 'Retirada na Loja',
                items: cart,
                total: totalFormatted,
                obs: orderData.obs,
                coupon: orderData.discount ? orderData.discount.codigo : null,
                fee: orderData.fee
            })
        }).catch(err => console.error("Erro ao enviar pedido para painel", err));

        if (orderData.method === 'Entrega') {
            msg += `\n🛵 *Taxa de Entrega:* ${orderData.fee}`;
        }

        msg += `\n💰 *Total Final:* ${totalFormatted}`;

        if (orderData.obs) {
            msg += `\n\n📝 *Obs:* ${orderData.obs}`;
        }

        const unit = currentUnit || units[0];
        const link = `https://wa.me/${unit.phone}?text=${encodeURIComponent(msg)}`;

        let html = `✅ <strong>Pedido Pronto!</strong><br>`;
        html += `Tipo: <strong>${orderData.method}</strong><br>`;
        html += `Cliente: ${orderData.name}<br>`;
        html += `Total: <strong>${totalFormatted}</strong><br>`;

        if (orderData.discount) {
            html += `<small style="color: #28a745;">(Desconto aplicado: ${orderData.discount.codigo})</small><br>`;
        }

        if (orderData.obs) html += `Obs: <small>${orderData.obs}</small><br>`;

        html += `<br><br>📍 Unidade: ${unit.name}`;
        html += `<br><br><a href="${link}" target="_blank" style="background-color: #25D366; color: white; padding: 10px 20px; border-radius: 20px; text-decoration: none; display: inline-block; font-weight: bold;">📲 Enviar para WhatsApp</a>`;

        addMessage(html, 'bot');

        setTimeout(() => showRatingUI(), 1500);

        cart = [];
        checkoutState = null;
        orderData = {};
    }

    // Função para exibir categorias do menu
    function showMenuCategories(introText = "Com certeza! O que você manda hoje? 😋") {
        awaitingMenuCategory = true;
        addMessage(`${introText}<br>Digite o número ou nome da opção:<br>1️⃣ <strong>Pizzas</strong><br>2️⃣ <strong>Churrasco</strong><br>3️⃣ <strong>Hambúrgueres</strong><br>4️⃣ <strong>Marmitex</strong><br>5️⃣ <strong>Bebidas</strong><br>6️⃣ <strong>Ver Tudo</strong><br>7️⃣ <strong>⭐ Favoritos</strong>`, 'bot');
    }

    // Buscar e Exibir Cardápio da API
    async function fetchAndShowMenu(filter = null) {
        try {
            addMessage("Buscando as melhores opções para você... 😋", 'bot');

            const response = await fetch('/api/cardapio');
            if (!response.ok) throw new Error('Erro na API');

            const menu = await response.json();

            if (Object.keys(menu).length === 0) {
                addMessage("O cardápio parece estar vazio no momento. 😕 Tente novamente mais tarde.", 'bot');
                return;
            }

            let html = "<strong>📋 Aqui está:</strong><br>";

            // Define quais categorias exibir
            let keysToShow = [];
            if (Array.isArray(filter)) keysToShow = filter;
            else if (filter) keysToShow = [filter];
            else keysToShow = Object.keys(menu); // Mostra tudo se não houver filtro

            for (const category of keysToShow) {
                const items = menu[category];
                if (!items) continue;

                html += `<div style="margin-top: 15px; border-bottom: 1px solid rgba(255,255,255,0.2); padding-bottom: 5px; margin-bottom: 5px;">
                            <strong style="color: #ffc107; text-transform: uppercase; font-size: 0.9em;">${category}</strong>
                         </div>`;
                items.forEach(item => {
                    const isFav = isFavorite(item.nome);
                    const star = isFav ? '⭐' : '☆';
                    const starColor = isFav ? '#ffc107' : 'rgba(255,255,255,0.5)';

                    html += `<div style="margin-bottom: 8px; padding: 4px 0; display: flex; align-items: center; justify-content: space-between;">
                                <div style="flex: 1;">
                                    <div style="display: flex; justify-content: space-between;"><strong>${item.nome}</strong> <span style="margin-left: 5px;">${item.preco}</span></div>
                                    <div style="font-size: 0.85em; opacity: 0.8; line-height: 1.2;">${item.desc}</div>
                                </div>
                                <div style="display: flex; gap: 5px; align-items: center; margin-left: 8px;">
                                    <button class="fav-btn" data-name="${item.nome}" data-price="${item.price}" data-desc="${item.desc}" style="background: transparent; border: none; cursor: pointer; font-size: 1.4em; color: ${starColor}; padding: 0;">${star}</button>
                                    <button class="add-cart-btn" data-name="${item.nome}" data-price="${item.price}" style="background: #28a745; border: none; color: white; width: 28px; height: 28px; border-radius: 50%; cursor: pointer; font-weight: bold; flex-shrink: 0;">+</button>
                                </div>
                             </div>`;
                });
            }

            html += `<div style="margin-top: 15px; text-align: center;">
                        <button class="back-to-menu-btn" style="background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.3); color: white; padding: 8px 16px; border-radius: 20px; cursor: pointer; font-size: 0.9em; transition: background 0.2s;">⬅ Voltar ao Menu</button>
                     </div>`;

            addMessage(html, 'bot');
        } catch (error) {
            console.error("Erro ao buscar cardápio", error);
            addMessage("Desculpe, tive um problema ao carregar o cardápio. 😕 Mas você pode ver na aba 'Cardápio' do site!", 'bot');
        }
    }

    // Carrega conhecimento
    fetch('/static/js/ai_knowledge.json')
        .then(response => response.json())
        .then(data => {
            knowledgeBase = data.keywords;
            fallbackResponse = data.fallback;
            input.disabled = false;
            sendBtn.disabled = false;
            input.placeholder = "Pergunte sobre pizzas, rodízio...";
        })
        .catch(err => console.error("Erro ao carregar IA", err));

    // Toggle Chat
    const toggleChat = () => {
        widget.classList.toggle('open');
        if (widget.classList.contains('open')) {
            if (badge) badge.style.display = 'none';
            input.focus();
        }
    };

    toggleBtn.addEventListener('click', toggleChat);
    closeBtn.addEventListener('click', toggleChat);

    // Event listener para botões dinâmicos (como "Voltar ao Menu")
    messagesContainer.addEventListener('click', (e) => {
        if (e.target.classList.contains('back-to-menu-btn')) {
            showMenuCategories("Sem problemas! Vamos escolher outra coisa. 😉");
        }
        if (e.target.classList.contains('add-cart-btn')) {
            const name = e.target.getAttribute('data-name');
            const price = e.target.getAttribute('data-price');
            addToCart(name, price);
        }
        if (e.target.classList.contains('finalize-order-btn')) {
            finalizeOrder();
        }
        if (e.target.classList.contains('view-cart-btn')) {
            showCart();
        }
        if (e.target.classList.contains('remove-cart-item-btn')) {
            const index = parseInt(e.target.getAttribute('data-index'));
            removeFromCart(index);
        }
        if (e.target.classList.contains('fav-btn')) {
            const btn = e.target;
            const name = btn.getAttribute('data-name');
            const price = btn.getAttribute('data-price');
            const desc = btn.getAttribute('data-desc');
            toggleFavorite(name, price, desc);
            const isFav = isFavorite(name);
            btn.textContent = isFav ? '⭐' : '☆';
            btn.style.color = isFav ? '#ffc107' : 'rgba(255,255,255,0.5)';
        }
        if (e.target.classList.contains('rate-star')) {
            const val = e.target.getAttribute('data-val');
            let stars = '★'.repeat(val);
            addMessage(`Obrigado pela avaliação! ${stars}<br>Ficamos felizes em atender você.`, 'bot');
            const container = e.target.closest('.rating-container');
            if (container) container.remove();
        }
    });

    // Saudação Inicial
    function getGreeting() {
        const status = getStoreStatus();
        if (status.isOpen) return "Boa noite! A chapa está quente 🔥. O que manda?";
        return `Olá! ${status.message} Posso ajudar com o cardápio ou agendar um pedido?`;
    }

    if (messagesContainer) {
        messagesContainer.innerHTML = `<div class="ai-message bot">${getGreeting()} Sou a Assistente da Colonial.</div>`;
    }

    clearBtn.addEventListener('click', () => {
        messagesContainer.innerHTML = `<div class="ai-message bot">${getGreeting()}</div>`;
    });

    // Adicionar Mensagem
    function addMessage(text, sender) {
        const div = document.createElement('div');
        div.className = `ai-message ${sender}`;
        div.innerHTML = text;
        messagesContainer.appendChild(div);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    // Processar Mensagem
    async function handleUserMessage() {
        const text = input.value.trim();
        if (!text) return;

        addMessage(text, 'user');
        input.value = '';

        // Indicador de digitação
        const loadingDiv = document.createElement('div');
        loadingDiv.className = 'typing-indicator';
        loadingDiv.innerHTML = '<span>.</span><span>.</span><span>.</span>';
        messagesContainer.appendChild(loadingDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;

        // --- Lógica de Checkout (Máquina de Estados) ---
        if (checkoutState) {
            loadingDiv.remove();

            // 1. Escolha do Método
            if (checkoutState === 'method') {
                if (text.match(/1|entrega/i)) {
                    orderData.method = 'Entrega';
                    checkoutState = 'cep';
                    addMessage("Ótimo! Por favor, digite o **CEP** para entrega:", 'bot');
                } else if (text.match(/2|retirada|buscar/i)) {
                    orderData.method = 'Retirada';

                    const savedName = localStorage.getItem('vts_user_name');
                    const savedPhone = localStorage.getItem('vts_user_phone');
                    if (savedName && savedPhone) {
                        checkoutState = 'check_saved';
                        addMessage(`Encontrei seus dados: <strong>${savedName}</strong> (${savedPhone}).<br>Deseja usá-los? (Sim/Não)`, 'bot');
                    } else {
                        checkoutState = 'name';
                        addMessage("Certo! Qual é o seu **nome**?", 'bot');
                    }
                } else {
                    addMessage("Por favor, escolha 1 para Entrega ou 2 para Retirada.", 'bot');
                }
                return;
            }

            // 2. Verificação de CEP (se Entrega)
            if (checkoutState === 'cep') {
                const cepClean = text.replace(/\D/g, '');
                if (cepClean.length !== 8) {
                    addMessage("CEP inválido. Digite os 8 números.", 'bot');
                    return;
                }

                try {
                    const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&countrycodes=br&limit=1&postalcode=${cepClean}&addressdetails=1`);
                    const data = await response.json();

                    if (!data || data.length === 0) {
                        addMessage("Não encontrei esse CEP. Tente novamente ou digite 'cancelar'.", 'bot');
                        return;
                    }

                    const userLat = parseFloat(data[0].lat);
                    const userLon = parseFloat(data[0].lon);
                    let minDistance = Infinity;
                    let nearestUnit = null;

                    units.forEach(unit => {
                        const dist = calculateDistance(userLat, userLon, unit.lat, unit.lon);
                        if (dist < minDistance) {
                            minDistance = dist;
                            nearestUnit = unit;
                        }
                    });

                    const address = data[0].address || {};
                    const street = address.road || address.street || address.pedestrian || address.footway || "Rua identificada";

                    if (minDistance <= 6) {
                        currentUnit = nearestUnit;
                        orderData.cep = text;
                        orderData.fee = calculateDeliveryFee(minDistance);

                        orderData.street = street;

                        checkoutState = 'address_number';
                        addMessage(`Entregamos sim! (Distância: ${minDistance.toFixed(1)}km)<br>📍 Rua: <strong>${street}</strong><br>Taxa: ${orderData.fee}<br><br>Por favor, digite o <strong>número e complemento</strong> (se houver).`, 'bot');
                    } else {
                        addMessage(`Poxa, a rua <strong>${street}</strong> fica muito longe (${minDistance.toFixed(1)}km). Nosso limite é 6km. 😕<br>Deseja mudar para **Retirada**? (Sim/Não)`, 'bot');
                        checkoutState = 'switch_method';
                    }
                } catch (e) {
                    addMessage("Erro ao verificar CEP. Tente novamente.", 'bot');
                }
                return;
            }

            // 2.5 Número e Complemento
            if (checkoutState === 'address_number') {
                // Validação: Verifica se tem pelo menos um dígito
                if (!/\d/.test(text)) {
                    addMessage("Parece que faltou o número. 🏠 Por favor, digite o **número** do endereço (ex: 123).", 'bot');
                    return;
                }
                orderData.number_complement = text;

                const savedName = localStorage.getItem('vts_user_name');
                const savedPhone = localStorage.getItem('vts_user_phone');
                if (savedName && savedPhone) {
                    checkoutState = 'check_saved';
                    addMessage(`Anotado! 📝<br>Encontrei seus dados: <strong>${savedName}</strong> (${savedPhone}).<br>Deseja usá-los? (Sim/Não)`, 'bot');
                } else {
                    checkoutState = 'name';
                    addMessage(`Anotado! 📝<br>Qual é o seu **nome**?`, 'bot');
                }
                return;
            }

            // 2.1 Alternativa se CEP for longe
            if (checkoutState === 'switch_method') {
                if (text.match(/sim|s|quero/i)) {
                    orderData.method = 'Retirada';
                    orderData.fee = 'R$ 0,00';

                    const savedName = localStorage.getItem('vts_user_name');
                    const savedPhone = localStorage.getItem('vts_user_phone');
                    if (savedName && savedPhone) {
                        checkoutState = 'check_saved';
                        addMessage(`Combinado! Retirada na loja.<br>Encontrei seus dados: <strong>${savedName}</strong> (${savedPhone}).<br>Deseja usá-los? (Sim/Não)`, 'bot');
                    } else {
                        checkoutState = 'name';
                        addMessage("Combinado! Retirada na loja. Qual é o seu **nome**?", 'bot');
                    }
                } else {
                    checkoutState = null;
                    addMessage("Tudo bem. Pedido cancelado. Se mudar de ideia, estou aqui!", 'bot');
                }
                return;
            }

            // 2.2 Verificar dados salvos
            if (checkoutState === 'check_saved') {
                if (text.match(/sim|s|pode|quero/i)) {
                    orderData.name = localStorage.getItem('vts_user_name');
                    orderData.phone = localStorage.getItem('vts_user_phone');
                    checkoutState = 'obs';
                    addMessage(`Dados confirmados! ✅<br>Alguma **observação** para o pedido? (Ex: sem cebola, troco para 50).<br>Se não tiver, digite 'não'.`, 'bot');
                } else {
                    checkoutState = 'name';
                    addMessage("Sem problemas. Qual é o seu **nome**?", 'bot');
                }
                return;
            }

            // 3. Nome
            if (checkoutState === 'name') {
                orderData.name = text;
                checkoutState = 'phone';
                addMessage("Prazer, " + text + "! Agora, qual seu **celular/WhatsApp** (com DDD)?", 'bot');
                return;
            }

            // 4. Telefone (com validação)
            if (checkoutState === 'phone') {
                const phoneClean = text.replace(/\D/g, '');
                if (phoneClean.length < 10) {
                    addMessage("O número parece curto demais. 📱 Por favor, digite o DDD + Número (mínimo 10 dígitos).", 'bot');
                    return;
                }
                orderData.phone = text;
                checkoutState = 'coupon';
                addMessage("Anotado! 📱<br>Você tem algum **cupom de desconto**? Digite o código ou 'não'.", 'bot');
                return;
            }

            // 5. Cupom
            if (checkoutState === 'coupon') {
                if (text.match(/^n(ão|ao)$/i)) {
                    checkoutState = 'obs';
                    addMessage("Sem problemas! Alguma **observação** para o pedido? (Ex: sem cebola, troco para 50).<br>Se não tiver, digite 'não'.", 'bot');
                } else {
                    // Validar Cupom na API
                    try {
                        const response = await fetch('/api/cupom/validar', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ codigo: text })
                        });
                        const data = await response.json();

                        if (data.valid) {
                            orderData.discount = data;
                            checkoutState = 'obs';
                            addMessage(`🎉 Cupom <strong>${data.codigo}</strong> aplicado com sucesso!<br>Alguma **observação** para o pedido? (Ex: sem cebola, troco para 50).<br>Se não tiver, digite 'não'.`, 'bot');
                        } else {
                            addMessage(`❌ ${data.message}<br>Tente outro código ou digite 'não' para seguir sem cupom.`, 'bot');
                        }
                    } catch (e) {
                        addMessage("Erro ao validar cupom. Digite 'não' para continuar.", 'bot');
                    }
                }
                return;
            }

            // 6. Observações e Finalização
            if (checkoutState === 'obs') {
                orderData.obs = text.match(/^n(ão|ao)$/i) ? '' : text;
                finishCheckout();
                return;
            }
        }

        // Verifica se é um CEP (XXXXX-XXX ou XXXXXXXX)
        const cepMatch = text.match(/\b\d{5}-?\d{3}\b/);
        if (cepMatch) {
            const cep = cepMatch[0].replace('-', '');
            const response = await processDeliveryCheck(cep);
            loadingDiv.remove();
            addMessage(response, 'bot');
            return;
        }

        // Verifica se está aguardando o bairro (Contexto)
        if (awaitingNeighborhood) {
            awaitingNeighborhood = false;
            const response = await processNeighborhoodCheck(text);
            loadingDiv.remove();
            addMessage(response, 'bot');
            return;
        }

        // Verifica se está aguardando escolha do tipo de comida
        if (awaitingMenuCategory) {
            const lowerText = text.toLowerCase();
            let filter = undefined;

            if (text === '2' || lowerText.includes('churrasco') || lowerText.includes('espeto')) filter = 'Churrasco';
            else if (text === '3' || lowerText.includes('hamburguer') || lowerText.includes('burger') || lowerText.includes('lanche')) filter = 'Hambúrgueres';
            else if (text === '4' || lowerText.includes('marmita') || lowerText.includes('almoço')) filter = 'Marmitex';
            else if (text === '5' || lowerText.includes('bebida') || lowerText.includes('refri')) filter = 'Bebidas';
            else if (text === '6' || lowerText.includes('tudo') || lowerText.includes('completo') || lowerText.includes('todos')) filter = null;
            else if (text === '7' || lowerText.includes('favorito')) {
                awaitingMenuCategory = false;
                loadingDiv.remove();
                showFavorites();
                return;
            }
            else if (lowerText.includes('doce') || lowerText.includes('sobremesa')) filter = 'Pizzas Doces';
            else if (lowerText.includes('salgada') || lowerText.includes('tradicional')) filter = 'Pizzas Salgadas';
            else if (text === '1' || lowerText.includes('pizza')) filter = ['Pizzas Salgadas', 'Pizzas Doces']; // Mostra ambas

            if (filter !== undefined) {
                awaitingMenuCategory = false;
                loadingDiv.remove();
                await fetchAndShowMenu(filter);
                return;
            } else {
                // Se não entendeu a categoria, mantém o estado e pergunta de novo
                loadingDiv.remove();
                addMessage("Não entendi. 😕 Digite o número ou nome:<br>1. Pizzas<br>2. Churrasco<br>3. Hambúrgueres<br>4. Marmitex<br>5. Bebidas<br>6. Ver Tudo<br>7. Favoritos", 'bot');
                return;
            }
        }

        // Verifica solicitação de finalizar pedido
        if (text.match(/\b(finalizar|fechar|pedido|carrinho|comprar)\b/i)) {
            loadingDiv.remove();
            finalizeOrder();
            return;
        }

        // Verifica solicitação de Cardápio (Integração API)
        if (text.match(/\b(cardápio|menu|opções|fome)\b/i)) {
            loadingDiv.remove();
            showMenuCategories();
            return;
        }

        setTimeout(() => {
            loadingDiv.remove();
            let response = fallbackResponse;

            // Lógica de busca
            for (const key in knowledgeBase) {
                try {
                    const regex = new RegExp(key, 'i');
                    if (regex.test(text)) {
                        const potential = knowledgeBase[key];
                        response = Array.isArray(potential) ? potential[Math.floor(Math.random() * potential.length)] : potential;
                        break;
                    }
                } catch (e) { }
            }

            addMessage(response, 'bot');
        }, 800);
    }

    sendBtn.addEventListener('click', handleUserMessage);
    input.addEventListener('keypress', (e) => { if (e.key === 'Enter') handleUserMessage(); });

    // Chips de Sugestão
    document.querySelectorAll('.ai-chip').forEach(chip => {
        chip.addEventListener('click', () => {
            input.value = chip.textContent;
            handleUserMessage();
        });
    });
}